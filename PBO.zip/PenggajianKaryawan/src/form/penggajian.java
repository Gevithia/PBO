/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package form;
import koneksi.Koneksi;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
/**
 *
 * @author fatih
 */
public class penggajian extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(penggajian.class.getName());
DefaultTableModel model;
    /**
     * Creates new form penggajian
     */
    int jumlahAnakGlobal = 0;
    public penggajian() {
        initComponents();
        setLocationRelativeTo(null);

        // default hidden
        jLabel12.setVisible(false);
        jLabel13.setVisible(false);
        txtTunjanganIstri.setVisible(false);
        txtTunjanganAnak.setVisible(false);
        jLabel2.setVisible(false);
        txtJumlahAnak.setVisible(false);

        tampilData();
        tampilKaryawan();
    }
    
     // ================= TAMPIL DATA =================
     public void tampilData() {

        model = new DefaultTableModel();

        model.addColumn("Id Penggajian");
        model.addColumn("Id Karyawan");
        model.addColumn("Nama");
        model.addColumn("Golongan");
        model.addColumn("Tanggal");
        model.addColumn("Gaji");
        model.addColumn("Istri");
        model.addColumn("Anak");
        model.addColumn("Lembur");
        model.addColumn("Potongan");
        model.addColumn("Total");

        tabelPenggajian.setModel(model);

        try {
            String sql = "SELECT * FROM penggajian";
            Connection conn = Koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("id_penggajian"),
                    rs.getString("id_karyawan"),
                    rs.getString("nama_karyawan"),
                    rs.getString("golongan"),
                    rs.getString("tanggal_gaji"),
                    rs.getDouble("jumlah_gaji"),
                    rs.getDouble("tunjangan_istri"),
                    rs.getDouble("tunjangan_anak"),
                    rs.getDouble("jumlah_lembur"),
                    rs.getDouble("potongan"),
                    rs.getDouble("total_gaji")
                });
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    // ================= COMBOBOX =================
    public void tampilKaryawan() {
    cbKaryawan.removeAllItems();

    // kasih default kosong
    cbKaryawan.addItem("-- Pilih Karyawan --");

    try {
        String sql = "SELECT * FROM karyawan";
        Connection conn = Koneksi.getKoneksi();
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            cbKaryawan.addItem(rs.getString("id_karyawan"));
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);
    }
}

    // ================= AMBIL DATA =================
    public void ambilDataKaryawan() {
        try {

            String sql =
    "SELECT k.nama_karyawan, k.status, k.jumlah_anak, g.nama_golongan, g.gaji_pokok, g.uang_transport, g.uang_makan " +
    "FROM karyawan k JOIN golongan g ON k.id_golongan = g.id_golongan " +
    "WHERE k.id_karyawan=?";

            Connection conn = Koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement(sql);
            
            if (cbKaryawan.getSelectedItem() == null) return;

            pst.setString(1, cbKaryawan.getSelectedItem().toString());

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

    txtNamaKaryawan.setText(rs.getString("nama_karyawan"));
    txtGolongan.setText(rs.getString("nama_golongan"));
    txtJumlahGaji.setText(rs.getString("gaji_pokok"));
    txtTransport.setText(rs.getString("uang_transport"));
    txtUangMakan.setText(rs.getString("uang_makan"));

    int jumlahAnak = rs.getInt("jumlah_anak");

// tampilkan ke field
txtJumlahAnak.setText(String.valueOf(jumlahAnak));

// simpan ke global
jumlahAnakGlobal = jumlahAnak;

                // STATUS
                if (rs.getString("status").equals("Menikah")) {

    txtTunjanganIstri.setText("");
    txtTunjanganAnak.setText("");

    txtTunjanganIstri.setVisible(true);
    txtTunjanganAnak.setVisible(true);
    txtJumlahAnak.setVisible(true);
    jLabel12.setVisible(true);
    jLabel13.setVisible(true);
    jLabel2.setVisible(true);

} else {
    txtTunjanganIstri.setText("0");
    txtTunjanganAnak.setText("0");

    txtTunjanganIstri.setVisible(false);
    txtTunjanganAnak.setVisible(false);
    txtJumlahAnak.setVisible(false);
    jLabel12.setVisible(false);
    jLabel13.setVisible(false);
    jLabel2.setVisible(false);
}
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
    
    // ================= LEMBUR =================
    public void ambilLembur() {
        try {
            String sql = "SELECT SUM(total_lembur) as total FROM lembur WHERE id_karyawan=?";
            Connection conn = Koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement(sql);
            
            if (cbKaryawan.getSelectedItem() == null) return;

            pst.setString(1, cbKaryawan.getSelectedItem().toString());

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                txtJumlahLembur.setText(String.valueOf(rs.getDouble("total")));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    // ================= HITUNG =================
    private void hitungTotal() {

        double gaji = parse(txtJumlahGaji.getText());
        double istri = parse(txtTunjanganIstri.getText());
        double anak = parse(txtTunjanganAnak.getText());
        double lembur = parse(txtJumlahLembur.getText());
        double transport = parse(txtTransport.getText());
        double makan = parse(txtUangMakan.getText());
        double potongan = parse(txtPotongan.getText());

        double total = gaji + istri + anak + lembur + transport + makan - potongan;

        txtTotalGaji.setText(String.valueOf(total));
    }

    // ================= PARSE AMAN =================
    private double parse(String x) {
        if (x == null || x.equals("")) return 0;
        return Double.parseDouble(x);
    }


    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel16 = new javax.swing.JLabel();
        btnSave = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnHapus = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelPenggajian = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtNamaKaryawan = new javax.swing.JTextField();
        txtIdPenggajian = new javax.swing.JTextField();
        txtJumlahGaji = new javax.swing.JTextField();
        txtJumlahLembur = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtPotongan = new javax.swing.JTextField();
        txtTotalGaji = new javax.swing.JTextField();
        cbKaryawan = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        txtGolongan = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtTunjanganIstri = new javax.swing.JTextField();
        txtTunjanganAnak = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtTransport = new javax.swing.JTextField();
        txtUangMakan = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtJumlahAnak = new javax.swing.JTextField();
        tglGaji = new com.toedter.calendar.JDateChooser();
        btnHitung = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel16.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel16.setText("DAFTAR GAJI KARYAWAN");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 14, -1, -1));

        btnSave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Logo/bookmark(1).png"))); // NOI18N
        btnSave.setText("Save");
        btnSave.addActionListener(this::btnSaveActionPerformed);
        getContentPane().add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 370, -1, -1));

        btnReset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Logo/reset(1).png"))); // NOI18N
        btnReset.setText("Reset");
        btnReset.addActionListener(this::btnResetActionPerformed);
        getContentPane().add(btnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 370, -1, -1));

        btnUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Logo/changes(1).png"))); // NOI18N
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        getContentPane().add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 370, -1, -1));

        btnHapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Logo/bin(1).png"))); // NOI18N
        btnHapus.setText("Hapus");
        btnHapus.addActionListener(this::btnHapusActionPerformed);
        getContentPane().add(btnHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 370, -1, -1));

        btnBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Logo/logout(1).png"))); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(this::btnBackActionPerformed);
        getContentPane().add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 370, -1, -1));

        tabelPenggajian.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelPenggajian.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelPenggajianMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelPenggajian);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 434, 890, 440));

        jLabel3.setText("Tanggal Gaji");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 227, 110, 22));

        jLabel4.setText("Id. Karyawan");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 103, 110, 22));

        jLabel5.setText("Nama Karyawan");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 144, 110, 22));

        jLabel6.setText("Golongan");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 185, 110, 22));

        jLabel7.setText("Gaji Pokok");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 267, 75, 22));

        jLabel8.setText("Jumlah Lembur");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 307, 110, 22));
        getContentPane().add(txtNamaKaryawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(264, 144, 186, -1));
        getContentPane().add(txtIdPenggajian, new org.netbeans.lib.awtextra.AbsoluteConstraints(264, 62, 185, -1));
        getContentPane().add(txtJumlahGaji, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 267, 186, -1));
        getContentPane().add(txtJumlahLembur, new org.netbeans.lib.awtextra.AbsoluteConstraints(264, 307, 186, -1));

        jLabel9.setText("Potongan");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(521, 62, 58, -1));

        jLabel10.setText("Total Gaji");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(526, 310, 58, -1));
        getContentPane().add(txtPotongan, new org.netbeans.lib.awtextra.AbsoluteConstraints(636, 62, 110, -1));
        getContentPane().add(txtTotalGaji, new org.netbeans.lib.awtextra.AbsoluteConstraints(636, 307, 110, -1));

        cbKaryawan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbKaryawan.addActionListener(this::cbKaryawanActionPerformed);
        getContentPane().add(cbKaryawan, new org.netbeans.lib.awtextra.AbsoluteConstraints(264, 103, 70, -1));

        jLabel11.setText("Id Penggajian");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(154, 62, 110, 22));
        getContentPane().add(txtGolongan, new org.netbeans.lib.awtextra.AbsoluteConstraints(264, 185, 186, -1));

        jLabel12.setText("Tunjangan Istri");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(521, 106, -1, -1));

        jLabel13.setText("Tunjangan Anak");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(526, 147, -1, -1));
        getContentPane().add(txtTunjanganIstri, new org.netbeans.lib.awtextra.AbsoluteConstraints(636, 103, 110, -1));
        getContentPane().add(txtTunjanganAnak, new org.netbeans.lib.awtextra.AbsoluteConstraints(636, 144, 110, -1));

        jLabel14.setText("Transport");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(526, 226, -1, -1));

        jLabel15.setText("Uang Makan");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(526, 270, -1, -1));
        getContentPane().add(txtTransport, new org.netbeans.lib.awtextra.AbsoluteConstraints(636, 226, 110, -1));
        getContentPane().add(txtUangMakan, new org.netbeans.lib.awtextra.AbsoluteConstraints(636, 267, 110, 24));

        jLabel2.setText("Jumlah Anak");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(526, 188, -1, -1));
        getContentPane().add(txtJumlahAnak, new org.netbeans.lib.awtextra.AbsoluteConstraints(636, 185, 110, -1));
        getContentPane().add(tglGaji, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 230, 140, -1));

        btnHitung.setIcon(new javax.swing.ImageIcon(getClass().getResource("/src/calculator(1).png"))); // NOI18N
        btnHitung.setText("Hitung");
        btnHitung.addActionListener(this::btnHitungActionPerformed);
        getContentPane().add(btnHitung, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 370, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        // TODO add your handling code here:
       try {

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String tanggal = sdf.format(tglGaji.getDate());

            String sql = "INSERT INTO penggajian "
        + "(id_penggajian, id_karyawan, nama_karyawan, golongan, tanggal_gaji, "
        + "jumlah_gaji, jumlah_lembur, potongan, total_gaji, tunjangan_istri, tunjangan_anak) "
        + "VALUES (?,?,?,?,?,?,?,?,?,?,?)";

Connection conn = Koneksi.getKoneksi();
PreparedStatement pst = conn.prepareStatement(sql);

pst.setString(1, txtIdPenggajian.getText());
pst.setString(2, cbKaryawan.getSelectedItem().toString());
pst.setString(3, txtNamaKaryawan.getText());
pst.setString(4, txtGolongan.getText());
pst.setString(5, tanggal);

// gaji pokok
pst.setDouble(6, parse(txtJumlahGaji.getText()));

// lembur ✅ (INI YANG SEBELUMNYA KETUKAR)
pst.setDouble(7, parse(txtJumlahLembur.getText()));

// potongan
pst.setDouble(8, parse(txtPotongan.getText()));

// total
pst.setDouble(9, parse(txtTotalGaji.getText()));

// tunjangan istri
pst.setDouble(10, parse(txtTunjanganIstri.getText()));

// tunjangan anak (pakai per anak × jumlah anak)
double anakInput = parse(txtTunjanganAnak.getText());
double anakTotal = anakInput * jumlahAnakGlobal;

pst.setDouble(11, anakTotal);

pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Berhasil disimpan");
            tampilData();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
        // TODO add your handling code here:
         txtIdPenggajian.setText("");
        txtNamaKaryawan.setText("");
        txtGolongan.setText("");
        txtJumlahGaji.setText("");
        txtTunjanganIstri.setText("");
        txtTunjanganAnak.setText("");
        txtJumlahLembur.setText("");
        txtPotongan.setText("");
        txtTotalGaji.setText("");
        txtTransport.setText("");
        txtUangMakan.setText("");
    }//GEN-LAST:event_btnResetActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
    try {

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String tanggal = sdf.format(tglGaji.getDate());

            String sql =
                    "UPDATE penggajian SET id_karyawan=?, nama_karyawan=?, golongan=?, tanggal_gaji=?, " +
                    "jumlah_gaji=?, tunjangan_istri=?, tunjangan_anak=?, jumlah_lembur=?, potongan=?, total_gaji=? " +
                    "WHERE id_penggajian=?";

            Connection conn = Koneksi.getKoneksi();
            PreparedStatement pst = conn.prepareStatement(sql);

            pst.setString(1, cbKaryawan.getSelectedItem().toString());
            pst.setString(2, txtNamaKaryawan.getText());
            pst.setString(3, txtGolongan.getText());
            pst.setString(4, tanggal);
            pst.setDouble(5, parse(txtJumlahGaji.getText()));
            pst.setDouble(6, parse(txtTunjanganIstri.getText()));
            pst.setDouble(7, parse(txtTunjanganAnak.getText()));
            pst.setDouble(8, parse(txtJumlahLembur.getText()));
            pst.setDouble(9, parse(txtPotongan.getText()));
            pst.setDouble(10, parse(txtTotalGaji.getText()));
            pst.setString(11, txtIdPenggajian.getText());

            pst.executeUpdate();

            JOptionPane.showMessageDialog(null, "Berhasil diupdate");
            tampilData();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        // TODO add your handling code here:
       try {

            String sql =
                    "DELETE FROM penggajian "
                    + "WHERE id_penggajian=?";

            Connection conn = Koneksi.getKoneksi();

            PreparedStatement pst =
                    conn.prepareStatement(sql);

            pst.setString(
                    1,
                    txtIdPenggajian.getText()
            );

            pst.executeUpdate();

            JOptionPane.showMessageDialog(
                    null,
                    "Data Berhasil Dihapus"
            );

            tampilData();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_btnHapusActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        // TODO add your handling code here:
         new menuutama().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void tabelPenggajianMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelPenggajianMouseClicked
        // TODO add your handling code here:
   int baris = tabelPenggajian.getSelectedRow();

        txtIdPenggajian.setText(tabelPenggajian.getValueAt(baris, 0).toString());
        cbKaryawan.setSelectedItem(tabelPenggajian.getValueAt(baris, 1).toString());
        txtNamaKaryawan.setText(tabelPenggajian.getValueAt(baris, 2).toString());
        txtGolongan.setText(tabelPenggajian.getValueAt(baris, 3).toString());
        txtJumlahGaji.setText(tabelPenggajian.getValueAt(baris, 5).toString());
        txtTunjanganIstri.setText(tabelPenggajian.getValueAt(baris, 6).toString());
        txtTunjanganAnak.setText(tabelPenggajian.getValueAt(baris, 7).toString());
        txtJumlahLembur.setText(tabelPenggajian.getValueAt(baris, 8).toString());
        txtPotongan.setText(tabelPenggajian.getValueAt(baris, 9).toString());
        txtTotalGaji.setText(tabelPenggajian.getValueAt(baris, 10).toString());

    }//GEN-LAST:event_tabelPenggajianMouseClicked

    private void cbKaryawanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbKaryawanActionPerformed
        if (cbKaryawan.getSelectedIndex() == 0) return;
        ambilDataKaryawan();
        ambilLembur();
    }//GEN-LAST:event_cbKaryawanActionPerformed

    private void btnHitungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHitungActionPerformed
        try {

            double gaji = parse(txtJumlahGaji.getText());
            double istri = parse(txtTunjanganIstri.getText());
            double anakInput = parse(txtTunjanganAnak.getText());

            // 🔥 ini kuncinya
            double anak = anakInput * jumlahAnakGlobal;

            double lembur = parse(txtJumlahLembur.getText());
            double transport = parse(txtTransport.getText());
            double makan = parse(txtUangMakan.getText());
            double potongan = parse(txtPotongan.getText());

            double total = gaji + istri + anak + lembur + transport + makan - potongan;

            txtTotalGaji.setText(String.valueOf(total));

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Input harus angka!");
        }
    }//GEN-LAST:event_btnHitungActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new penggajian().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnHitung;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cbKaryawan;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelPenggajian;
    private com.toedter.calendar.JDateChooser tglGaji;
    private javax.swing.JTextField txtGolongan;
    private javax.swing.JTextField txtIdPenggajian;
    private javax.swing.JTextField txtJumlahAnak;
    private javax.swing.JTextField txtJumlahGaji;
    private javax.swing.JTextField txtJumlahLembur;
    private javax.swing.JTextField txtNamaKaryawan;
    private javax.swing.JTextField txtPotongan;
    private javax.swing.JTextField txtTotalGaji;
    private javax.swing.JTextField txtTransport;
    private javax.swing.JTextField txtTunjanganAnak;
    private javax.swing.JTextField txtTunjanganIstri;
    private javax.swing.JTextField txtUangMakan;
    // End of variables declaration//GEN-END:variables
}
